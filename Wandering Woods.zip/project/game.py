import tkinter as tk
import tkinter.ttk as ttk
import tkinter.messagebox as messagebox
import tkinter.simpledialog as simpledialog
import random
import time
import winsound

class WanderingInTheWoods:
    def __init__(self, master):
        self.master = master
        self.master.title("Wandering in the Woods")
        
        # Main Menu
        self.menu_frame = tk.Frame(self.master)
        self.menu_frame.pack(pady=20)
        
        # Grade selection
        self.grade_label = tk.Label(self.menu_frame, text="Select Grade:")
        self.grade_label.grid(row=0, column=0, padx=10, pady=10)
        
        self.grade_var = tk.StringVar()
        self.grade_var.set("K-2")
        self.grade_menu = ttk.Combobox(self.menu_frame, textvariable=self.grade_var, values=["K-2", "3-5", "6-8"])
        self.grade_menu.grid(row=0, column=1, padx=10, pady=10)
        
        # Start game button
        self.start_button = tk.Button(self.menu_frame, text="Start Game", command=self.setup_game)
        self.start_button.grid(row=1, column=0, columnspan=2, pady=20)

    def setup_game(self):
        grade = self.grade_var.get()
        
        # Remove menu frame
        self.menu_frame.pack_forget()
        
        # Initialize game variables
        self.moves = {'red': 0, 'blue': 0, 'green': 0, 'yellow': 0}
        self.start_time = time.time()
        
        # Create grid based on grade
        if grade == "K-2":
            self.grid_size = (5, 5)
            self.active_players = 2
            self.start_positions = [(0, 0), (4, 4)]
            self.protocol = "random"
        elif grade == "3-5":
            rows = int(simpledialog.askstring("Grid Size", "Enter number of rows:"))
            cols = int(simpledialog.askstring("Grid Size", "Enter number of columns:"))
            self.grid_size = (rows, cols)
            self.active_players = int(simpledialog.askstring("Number of Players", "Enter number of players (2-4):"))
            self.start_positions = random.sample([(i, j) for i in range(rows) for j in range(cols)], self.active_players)
            self.protocol = "random"
        else:  # grade == "6-8"
            rows = int(simpledialog.askstring("Grid Size", "Enter number of rows:"))
            cols = int(simpledialog.askstring("Grid Size", "Enter number of columns:"))
            self.grid_size = (rows, cols)
            self.active_players = int(simpledialog.askstring("Number of Players", "Enter number of players (2-4):"))
            self.start_positions = random.sample([(i, j) for i in range(rows) for j in range(cols)], self.active_players)
            self.protocol = simpledialog.askstring("Wandering Protocol", "Choose a wandering protocol (clockwise, anticlockwise, random):")
        
        # Create grid
        self.grid_frame = tk.Frame(self.master)
        self.grid_frame.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)
        
        self.grid = [[None for _ in range(self.grid_size[1])] for _ in range(self.grid_size[0])]
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                self.grid[i][j] = tk.Button(self.grid_frame, width=10, height=3)
                self.grid[i][j].grid(row=i, column=j)
        
        # Place players
        self.players = ['red', 'blue', 'green', 'yellow'][:self.active_players]
        for idx, pos in enumerate(self.start_positions):
            self.grid[pos[0]][pos[1]].config(bg=self.players[idx])
        
        winsound.PlaySound("SystemHand", winsound.SND_ASYNC | winsound.SND_ALIAS )
        self.master.after(1000, self.move_players)

    def move_players(self):
        directions = [(0,1), (1,0), (0,-1), (-1,0)]
        clockwise = [(0,1), (1,0), (0,-1), (-1,0)]
        anticlockwise = [(0,-1), (-1,0), (0,1), (1,0)]
        
        for player in self.players:
            for i in range(self.grid_size[0]):
                for j in range(self.grid_size[1]):
                    if self.grid[i][j].cget("bg") == player:
                        if self.protocol == "random":
                            dx, dy = random.choice(directions)
                        elif self.protocol == "clockwise":
                            dx, dy = clockwise[(clockwise.index((i,j)) + 1) % 4]
                        elif self.protocol == "anticlockwise":
                            dx, dy = anticlockwise[(anticlockwise.index((i,j)) + 1) % 4]
                        
                        new_x, new_y = i + dx, j + dy
                        if 0 <= new_x < self.grid_size[0] and 0 <= new_y < self.grid_size[1] and self.grid[new_x][new_y].cget("bg") == 'SystemButtonFace':
                            self.grid[i][j].config(bg='SystemButtonFace')
                            self.grid[new_x][new_y].config(bg=player)
                            self.moves[player] += 1
                        elif 0 <= new_x < self.grid_size[0] and 0 <= new_y < self.grid_size[1] and self.grid[new_x][new_y].cget("bg") in self.players:
                            # Players met
                            end_time = time.time()
                            total_time = end_time - self.start_time
                            stats_text = f"Red moves: {self.moves['red']}\nBlue moves: {self.moves['blue']}\nTotal time: {total_time:.2f} seconds"
                            winsound.PlaySound("SystemExit", winsound.SND_ASYNC | winsound.SND_ALIAS )
                            messagebox.showinfo("Game Over", stats_text)
                            self.grid_frame.pack_forget()
                            self.menu_frame.pack(pady=20)
                            return
                        break
        
        self.master.after(1000, self.move_players)

if __name__ == "__main__":
    root = tk.Tk()
    game = WanderingInTheWoods(root)
    root.mainloop()
